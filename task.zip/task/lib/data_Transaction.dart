import 'package:flutter/material.dart';

class DataTransaction extends StatelessWidget {
  final String name;
  final String speciality;

  const DataTransaction({super.key, required this.name, required this.speciality});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       backgroundColor: Colors.white,
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircleAvatar(
                radius: 70,
                backgroundImage: const AssetImage("lib\\174875.jpg"),
              ),
              const SizedBox(height: 30),
              Text(
                "Hi, I am $name,\n$speciality",
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E2432),
                  height: 1.3,
                ),
              ),
              const SizedBox(height: 20),
              const Text(
               "I’m a penetration tester with a strong interest in cybersecurity and ethical hacking. I enjoy exploring system vulnerabilities, learning new security tools, and improving my skills to help protect digital environments.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.black54,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}
